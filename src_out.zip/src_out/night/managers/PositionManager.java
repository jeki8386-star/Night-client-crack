/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.ServerboundMovePlayerPacket
 *  net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket
 *  net.minecraft.network.protocol.game.ServerboundPlayerInputPacket
 *  net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket
 */
package night.managers;

import lombok.Generated;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerInputPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketSendEvent;
import night.utils.IMinecraft;

public class PositionManager
implements IMinecraft {
    private double serverX;
    private double serverY;
    private double serverZ;
    private boolean serverOnGround;
    private boolean serverSprinting;
    private boolean serverSneaking;
    private int serverSlot;

    public PositionManager() {
        Night.EVENT_HANDLER.subscribe(this);
    }

    @SubscribeEvent
    public void onPacketSend(PacketSendEvent event) {
        ServerboundMovePlayerPacket packet;
        if (PositionManager.mc.player == null) {
            return;
        }
        Packet<?> packet2 = event.getPacket();
        if (packet2 instanceof ServerboundMovePlayerPacket) {
            packet = (ServerboundMovePlayerPacket)packet2;
            if (packet.hasPosition()) {
                this.serverX = packet.getX(PositionManager.mc.player.getX());
                this.serverY = packet.getY(PositionManager.mc.player.getY());
                this.serverZ = packet.getZ(PositionManager.mc.player.getZ());
            }
            this.serverOnGround = packet.isOnGround();
        }
        if ((packet2 = event.getPacket()) instanceof ServerboundSetCarriedItemPacket) {
            packet = (ServerboundSetCarriedItemPacket)packet2;
            this.serverSlot = packet.getSlot();
        }
        if ((packet2 = event.getPacket()) instanceof ServerboundPlayerCommandPacket) {
            packet = (ServerboundPlayerCommandPacket)packet2;
            switch (packet.getAction()) {
                case START_SPRINTING: {
                    this.serverSprinting = true;
                    break;
                }
                case STOP_SPRINTING: {
                    this.serverSprinting = false;
                    break;
                }
            }
        }
        if ((packet2 = event.getPacket()) instanceof ServerboundPlayerInputPacket) {
            packet = (ServerboundPlayerInputPacket)packet2;
            this.serverSneaking = packet.input().shift();
        }
    }

    public double getServerX() {
        return PositionManager.mc.player != null ? PositionManager.mc.player.getX() : this.serverX;
    }

    public double getServerY() {
        return PositionManager.mc.player != null ? PositionManager.mc.player.getY() : this.serverY;
    }

    public double getServerZ() {
        return PositionManager.mc.player != null ? PositionManager.mc.player.getZ() : this.serverZ;
    }

    public boolean isServerOnGround() {
        return PositionManager.mc.player != null ? PositionManager.mc.player.onGround() : this.serverOnGround;
    }

    @Generated
    public boolean isServerSprinting() {
        return this.serverSprinting;
    }

    @Generated
    public boolean isServerSneaking() {
        return this.serverSneaking;
    }

    @Generated
    public int getServerSlot() {
        return this.serverSlot;
    }
}

